web_scraper.py 

A static web scraper used to obtain data for OMV prices of cars. Data was scraped from LTA.


Retrieved from: https://onemotoring.lta.gov.sg/content/onemotoring/home/buying/upfront-vehicle-costs/

Due to the massive number of HTML requests generated, the code will take a while to complete running.

----------------------------------------------------------------------------------

out.xlsx

Data of OMV of cars sold from 2002-2023.

The data scraped by web_scraper.py after cleaning.

----------------------------------------------------------------------------------

BIKE DETAILS.csv

Data of various motorcycles sold from 2006 to 2019. 

Data was taken from Kaggle.

Retrieved from https://www.kaggle.com/datasets/nehalbirla/motorcycle-dataset

----------------------------------------------------------------------------------

ALL Prices 1990-2021 mar.csv

Data of resale HDB flats from 1990 to 2021. Unused data was removed due to file size limitations.

Data was taken from Kaggle.

Retrieved from https://www.kaggle.com/datasets/denzilg/hdb-flat-prices-19902021-march

----------------------------------------------------------------------------------

rental price data.csv

Data of HDB rental prices from 2005 to 2021.

Data was taken from Data.gov.sg.

Retrieved from https://data.gov.sg/dataset/median-rent-by-town-and-flat-type


---------------------------------------------------------------------------------

Results of COE Bidding Exercise - Results.csv

Data of COE bidding results from 2002 to 2023.

Data was taken from SGCharts.

Retrived from https://coe.sgcharts.com/

---------------------------------------------------------------------------------


