import pandas as pd
import requests
from bs4 import BeautifulSoup


def get_values(soup, year):
    #Parse engine size and price from html
    prices = list()
    for month in range(1, 13):
        price = 1
        make = -1
        finish = 0
        while price:
            make += 1
            if make == 0 and month == 1:
                continue
            brand = soup.find(id = 'brandValue_make-{}_{}_{}'.format(make, month, year))
            model = -1
            while True:
                model += 1
                if model == 0 and make == 0 and month == 1:
                    continue
                price = soup.find(id='averageOmv_model-{}_make-{}_{}_{}'.format(model, make, month, year))
                engine_size = soup.find(id='modelValue_model-{}_make-{}_{}_{}'.format(model, make, month, year))
                if not price:
                    if model == 0:
                        finish = 1
                    price = 1
                    break


                query = [str(engine_size).split('"')[-2], year, month, str(price).split('"')[-2], str(brand).split('"')[-2]]
                prices.append(query)
            if finish:
                break

    return prices




df = pd.DataFrame()

for x in range(2004, 2024):
    #load html from onemotoring.lta.gov.sg
    data = requests.get(
        "https://onemotoring.lta.gov.sg/content/onemotoring/home/buying/upfront-vehicle-costs/open-market-value--omv-.html?year={}".format(
            x)).text
    soup = BeautifulSoup(data, 'html.parser')
    price = get_values(soup, x)
    current = pd.DataFrame(price, columns=["size", "year", "month", "value", "brand"])
    print("Now at {}".format(x))
    if df.empty:
        df = current
    else:
        df = pd.concat([current, df])
df.to_csv('out.csv', index=False)
