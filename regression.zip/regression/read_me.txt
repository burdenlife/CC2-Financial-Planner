Data analysis and creation of regression models

Dependencies: Python 3, pandas, seaborn, matplotlib, sklearn

#The file dependencies can be found in data.zip

------------------------------------------------------------

carprice.ipynb -> regression of car prices 

File dependency: out.xlsx

------------------------------------------------------------

motorcycle.ipynb -> regression of motorcycle prices 

File dependency: BIKE DETAILS.csv

------------------------------------------------------------

housing.ipynb -> regression of HDB flat resale prices

File dependency: ALL prices 1990-2021 mar.csv

------------------------------------------------------------

rental.ipynb -> regression of rental prices of HDB flats

File dependency: rental price data.csv

------------------------------------------------------------

coeprice.ipynm -> regression of COE prices for cat A,B,D

File dependency:Results of COE Bidding Exercise - Results.csv