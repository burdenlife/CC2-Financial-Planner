main.py

The source code for Financial Planner application.

Dependencies: Python 3, pandas, sklearn, scipy


---------------------------------------------------------

data files

Dependencies for main.py. 

If relocated from main.py adjust FILENAME variable. The code is defaulted to running from the same folder.