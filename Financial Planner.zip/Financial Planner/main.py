import tkinter as tk
import pandas as pd
from sklearn.model_selection import train_test_split

FILEPATH = '.\\'

housing = True
car = True

house_or_rental_price = 0
housing_rent_duration = 0


def rent_command(house_button):
    global housing
    house_button.destroy()
    housing = False


def house_command(rent_button):
    rent_button.destroy()


def yes_command(no_button):
    no_button.destroy()


def no_command(yes_button):
    global car
    car = False
    yes_button.destroy()


def start_frame(frame):
    q_describe = tk.Label(frame, text="Select quarter of purchase/rent of house", font=('Arial', 17))
    q_describe.place(x=5, y=55)

    q_describe = tk.Label(frame, text="Select quarter of Car purchase", font=('Arial', 17))
    q_describe.place(x=5, y=55)

    y_label = tk.Label(frame, text="Year:", font=('Arial', 15))
    y_label.place(x=5, y=95)

    q_label = tk.Label(frame, text="Quarter:", font=('Arial', 15))
    q_label.place(x=5, y=130)

    year_list = list(range(2024, 2034))
    q_selected = tk.StringVar(frame)
    q_selected.set("Select Quarter")

    y_selected = tk.StringVar(frame)
    y_selected.set("Select Year")
    year_menu = tk.OptionMenu(frame, y_selected, *year_list)
    year_menu.place(x=90, y=95)

    year_menu.config(font=('Arial', 11))
    menu = frame.nametowidget(year_menu.menuname)
    menu.config(font=('Arial', 13))

    options = ['Q1', 'Q2', 'Q3', 'Q4']
    quarter_menu = tk.OptionMenu(frame, q_selected, *options, )
    quarter_menu.place(x=90, y=130)

    quarter_menu.config(font=('Arial', 11))
    menu = frame.nametowidget(quarter_menu.menuname)
    menu.config(font=('Arial', 13))

    type_label = tk.Label(frame, text="Are you Renting or Purchasing your residence?", font=('Arial', 17))
    type_label.place(x=5, y=190)

    rent_button = tk.Button(frame, text="Rent", font=('Arial', 15), bg='lime')
    rent_button.place(x=120, y=230)

    buy_button = tk.Button(frame, text="Purchase", font=('Arial', 15), bg='red',
                           command=lambda: house_command(rent_button))
    buy_button.place(x=5, y=230)

    rent_button['command'] = lambda: rent_command(buy_button)
    return q_selected, y_selected


def car(frame):
    type_label = tk.Label(frame, text="Are you Purchasing a Car/Motorcycle?", font=('Arial', 17))
    type_label.place(x=5, y=300)
    yes_button = tk.Button(frame, text="Yes", font=('Arial', 15), bg='lime')
    yes_button.place(x=120, y=340)

    no_button = tk.Button(frame, text="No", font=('Arial', 15), bg='red',
                          command=lambda: no_command(yes_button))
    no_button.place(x=5, y=340)
    yes_button['command'] = lambda: yes_command(no_button)


def next_button(frame, hse):
    next_button = tk.Button(frame, text="Next", bg='pink', font=('Arial', 18), command=lambda: house_window(frame, hse))
    next_button.place(x=300, y=400)


def next_button_2(root, values, data):
    global house_or_rental_price
    if housing:
        from sklearn.linear_model import LinearRegression
        global housing_rent_duration
        flat_type, lease, town, loan, q_selected, y_selected = values
        housing_rent_duration = int(loan.get())
        x = data[[x for x in data.columns if x != 'resale_price']]
        y = data['resale_price']
        X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=100)
        reg = LinearRegression()
        reg.fit(X_train, y_train)
        categories = list(data.columns)
        categories.remove('resale_price')

        year = int(y_selected.get())
        q_string = q_selected.get()
        quarter = (year - 1990) * 4 + int(q_string[-1])

        variables = [0] * (len(data.columns) - 1)
        variables[0] = quarter
        variables[1] = int(lease.get())
        if flat_type.get() != '1 ROOM':
            flat_type_index = categories.index(flat_type.get())
            variables[flat_type_index] = 1

        if town.get() != 'ANG MO KIO':
            town_index = categories.index(town.get())
            variables[town_index] = 1
        house_or_rental_price = int(reg.predict([variables])[0])

    else:
        from sklearn.kernel_ridge import KernelRidge
        flat_type, town, q_selected, y_selected = values
        categories = list(data.columns)
        categories.remove('median_rent')
        predictors = data[categories]
        responses = data["median_rent"]

        X_train, X_test, y_train, y_test = train_test_split(predictors, responses, test_size=0.20);

        krr = KernelRidge(alpha=1.225, kernel='polynomial', degree=4)
        krr.fit(X_train, y_train)

        year = int(y_selected.get())
        q_string = q_selected.get()
        quarter = (year - 1990) * 4 + int(q_string[-1])

        variables = [0] * (len(data.columns) - 1)
        variables[0] = quarter
        if flat_type.get() != '2-RM':
            flat_type_index = categories.index(flat_type.get())
            variables[flat_type_index] = 1

        if town.get() != 'ANGMOKIO':
            town_index = categories.index(town.get())
            variables[town_index] = 1
        house_or_rental_price = int(krr.predict([variables])[0])

    if car:
        car_window(root)
    else:
        end_frame(root)


def vehicle_frame(frame):
    title = tk.Label(frame, text="Vehicle Category", font=('Arial', 20))
    title.place(x=5, y=5)

    size_describe = tk.Label(frame, text="Select the category of your vehicle", font=('Arial', 15))
    size_describe.place(x=5, y=55)
    size_label = tk.Label(frame, text="Size:", font=('Arial', 15))
    size_label.place(x=5, y=100)
    category = tk.StringVar(frame)
    category.set("Select size of the vehicle you would like to purchase")
    size_list = ['Cat A - Less than 1600cc', 'Cat B - More than 1600cc', 'Cat D - Motorcycle']
    size = tk.OptionMenu(frame, category, *size_list, )
    size.place(x=80, y=100)

    size.config(font=('Arial', 12))
    menu = frame.nametowidget(size.menuname)
    menu.config(font=('Arial', 13))

    return category


def car_window(root):
    frame = tk.Frame(root, width=700, height=700)
    frame.place(x=5, y=0)
    category = vehicle_frame(frame)

    submitbutton = tk.Button(frame, text="Submit", command=lambda: vehicle_frame_2(root, frame, category), bg='pink',
                             font=('Arial', 15))
    submitbutton.place(x=300, y=220)


def motorcycle_frame(frame, brands):
    title = tk.Label(frame, text="Motorcycle Price Estimate", font=('Arial', 20))
    title.place(x=5, y=5)

    q_label = tk.Label(frame, text="Brand:", font=('Arial', 15))
    q_label.place(x=5, y=180)

    brand = tk.StringVar(frame)
    brand.set("Select Motorcycle Brand")
    brand_menu = tk.OptionMenu(frame, brand, *brands, )
    brand_menu.place(x=80, y=180)

    brand_menu.config(font=('Arial', 11))
    menu = frame.nametowidget(brand_menu.menuname)
    menu.config(font=('Arial', 13))

    q_describe = tk.Label(frame, text="Select quarter of Motorcycle purchase", font=('Arial', 15))
    q_describe.place(x=5, y=55)

    y_label = tk.Label(frame, text="Year:", font=('Arial', 15))
    y_label.place(x=5, y=95)

    q_label = tk.Label(frame, text="Quarter:", font=('Arial', 15))
    q_label.place(x=5, y=130)

    year_list = list(range(2024, 2034))
    q_selected = tk.StringVar(frame)
    q_selected.set("Select Quarter")

    y_selected = tk.StringVar(frame)
    y_selected.set("Select Year")
    year_menu = tk.OptionMenu(frame, y_selected, *year_list)
    year_menu.place(x=90, y=95)

    year_menu.config(font=('Arial', 12))
    menu = frame.nametowidget(year_menu.menuname)
    menu.config(font=('Arial', 13))

    options = ['Q1', 'Q2', 'Q3', 'Q4']
    quarter_menu = tk.OptionMenu(frame, q_selected, *options, )
    quarter_menu.place(x=90, y=130)

    quarter_menu.config(font=('Arial', 11))
    menu = frame.nametowidget(quarter_menu.menuname)
    menu.config(font=('Arial', 13))

    loan = get_loan(frame, 7, 5, 240)

    return brand, q_selected, y_selected, loan


def car_frame(frame, brands):
    title = tk.Label(frame, text="Car Price Estimate", font=('Arial', 20))
    title.place(x=5, y=5)

    b_label = tk.Label(frame, text="Brand:", font=('Arial', 15))
    b_label.place(x=5, y=180)

    brand = tk.StringVar(frame)
    brand.set("Select Car Brand")
    brand_menu = tk.OptionMenu(frame, brand, *sorted(brands), )
    brand_menu.place(x=80, y=180)

    brand_menu.config(font=('Arial', 11))

    q_describe = tk.Label(frame, text="Select quarter of Car purchase", font=('Arial', 15))
    q_describe.place(x=5, y=55)

    y_label = tk.Label(frame, text="Year:", font=('Arial', 15))
    y_label.place(x=5, y=95)

    q_label = tk.Label(frame, text="Quarter:", font=('Arial', 15))
    q_label.place(x=5, y=130)

    year_list = list(range(2024, 2034))
    q_selected = tk.StringVar(frame)
    q_selected.set("Select Quarter")

    y_selected = tk.StringVar(frame)
    y_selected.set("Select Year")
    year_menu = tk.OptionMenu(frame, y_selected, *year_list)
    year_menu.place(x=90, y=95)

    year_menu.config(font=('Arial', 11))
    menu = frame.nametowidget(year_menu.menuname)
    menu.config(font=('Arial', 13))

    options = ['Q1', 'Q2', 'Q3', 'Q4']
    quarter_menu = tk.OptionMenu(frame, q_selected, *options, )
    quarter_menu.place(x=90, y=130)

    quarter_menu.config(font=('Arial', 11))
    menu = frame.nametowidget(quarter_menu.menuname)
    menu.config(font=('Arial', 13))

    loan = get_loan(frame, 7, 5, 240)

    return brand, q_selected, y_selected, loan


def vehicle_frame_2(root, old_frame, category):
    old_frame.destroy()

    cat = category.get()[4]

    frame = tk.Frame(root, width=700, height=700)
    frame.place(x=0, y=0)

    if cat == 'D':
        data = pd.read_csv("{}Motorcycle price data.csv".format(FILEPATH))
        brands = sorted(set(data['brand']))
        variables = list(motorcycle_frame(frame, brands))
        variables.append(data)

    else:
        with open('ordered car brands.csv') as f:
            data = f.read()
        brands = data.split(',')
        variables = list(car_frame(frame, brands))
        variables.append(data)

    submitbutton = tk.Button(frame, text="Submit", command=lambda: end_frame(root, variables, cat), bg='pink',
                             font=('Arial', 18))
    submitbutton.place(x=300, y=300)


def create_bike_regression(data):
    variable_fields = [x for x in data.columns if x not in ('selling_price', 'brand')]
    variables = data[variable_fields]
    price = data[['selling_price']]

    X_train, X_test, y_train, y_test = train_test_split(variables, price, test_size=0.2, random_state=100)

    from sklearn.kernel_ridge import KernelRidge
    krr = KernelRidge(kernel='polynomial', degree=4)
    krr.fit(X_train, y_train)

    return krr


def calculate_payment(principal, interest, n_years):
    from scipy.optimize import fsolve
    equation = (n_years - 1) * '(' + str(principal) + ('-12*x)*(1+' + str(interest) + ')') * (n_years - 1) + '-12*x'
    command = 'f = lambda x: {}'.format(equation)
    ldict = {}
    exec(command, globals(), ldict)
    f = ldict['f']
    estimate = principal * (1 + interest) / (n_years * 12)
    answer = fsolve(f, estimate)[0]
    return int(answer)


def end_frame(root, variables=None, cat=None):
    frame = tk.Frame(root, height=700, width=700)
    frame.place(x=0, y=0)
    title = tk.Label(frame, text="Your Financial Plan", font=('Arial', 24))
    title.place(x=5, y=5)

    if housing:
        label = tk.Label(frame, font=('Arial', 18),
                         text="Housing Price: ${}".format("{:,}".format(house_or_rental_price)))
        label.place(x=5, y=70)

        if housing_rent_duration == 0:
            label = tk.Label(frame, font=('Arial', 18),
                             text="Cash Upfront(housing): ${:,}".format(house_or_rental_price))
            label.place(x=5, y=110)
        else:
            min_cash = int(0.2 * house_or_rental_price)

            label = tk.Label(frame, font=('Arial', 18), text="Cash Upfront(housing): ${:,}".format(min_cash))
            label.place(x=5, y=110)

            loan = 0.8 * house_or_rental_price
            monthly_payment = calculate_payment(loan, 0.026, housing_rent_duration)

            label = tk.Label(frame, font=('Arial', 18), text="Monthly Payment(housing): ${:,}".format(monthly_payment))
            label.place(x=5, y=150)

    else:
        label = tk.Label(frame, font=('Arial', 18), text="Monthly Payment(rental): ${:,}".format(house_or_rental_price))
        label.place(x=5, y=75)

    if car:
        if cat == 'D':
            brand, q_selected, y_selected, car_loan, data = variables
            q_string = q_selected.get()
            year = int(y_selected.get())
            quarter = (year - 2002) * 4 + int(q_string[-1])
            categories = list(data.columns)
            categories.remove('brand')
            datapoint = [0] * (len(data.columns) - 2)
            datapoint[0] = year

            if brand.get() != 'Aprilia':
                brand_index = categories.index(brand.get())
                datapoint[brand_index] = 1
            krr = create_bike_regression(data)
            car_price = int(krr.predict([datapoint])[0])

            coe_price = -1710 + 121 * quarter


        else:
            brand, q_selected, y_selected, car_loan, ordered_brands = variables
            q_string = q_selected.get()
            year = int(y_selected.get())
            quarter = (year - 2002) * 4 + int(q_string[-1])
            brand_index = ordered_brands.index(brand.get())

            if cat == 'A':
                car_price = 5695 + 343 * brand_index + 97 * quarter
                coe_price = 17336 + 512 * quarter

            else:
                car_price = 3950 + 769 * brand_index + 16 * quarter
                coe_price = 16666 + 685 * quarter

        loan_duration = int(car_loan.get())

        if loan_duration == 0:
            car_price += coe_price
            vehicle_label = tk.Label(frame, font=('Arial', 18), text="Vehicle Price: ${:,}".format(car_price))
            vehicle_label.place(x=5, y=210)
            label = tk.Label(frame, font=('Arial', 18), text="Cash Upfront(vehicle): ${:,}".format(car_price))
            label.place(x=5, y=260)


        elif car_price <= 20000:
            car_price += coe_price
            vehicle_label = tk.Label(frame, font=('Arial', 18), text="Vehicle Price: ${:,}".format(car_price))
            vehicle_label.place(x=5, y=220)
            min_cash = int(0.3 * car_price)
            label = tk.Label(frame, font=('Arial', 18), text="Cash Upfront(vehicle): ${:,}".format(min_cash))
            label.place(x=5, y=260)
            loan = 0.7 * car_price
            monthly_payment = calculate_payment(loan, 0.0278, loan_duration)

            label = tk.Label(frame, font=('Arial', 18), text="Monthly Payment(vehicle): ${:,}".format(monthly_payment))
            label.place(x=5, y=300)

        else:
            car_price += coe_price
            vehicle_label = tk.Label(frame, font=('Arial', 18), text="Vehicle Price: ${:,}".format(car_price))
            vehicle_label.place(x=5, y=220)

            min_cash = int(0.4 * car_price)
            label = tk.Label(frame, font=('Arial', 18), text="Cash Upfront(vehicle): ${:,}".format(min_cash))
            label.place(x=5, y=260)
            loan = 0.6 * house_or_rental_price
            monthly_payment = calculate_payment(loan, 0.0278, loan_duration)

            label = tk.Label(frame, font=('Arial', 18), text="Monthly Payment(vehicle): ${:,}".format(monthly_payment))
            label.place(x=5, y=300)


def get_town(frame, towns):
    label = tk.Label(frame, text="Region:", font=('Arial', 15))
    label.place(x=5, y=60)
    region = tk.StringVar(frame)
    options = towns
    e = tk.OptionMenu(frame, region, *options)
    e.place(x=200, y=60)

    e.config(font=('Arial', 11))
    menu = frame.nametowidget(e.menuname)
    menu.config(font=('Arial', 12))
    return region


def get_rooms(frame, flat_types):
    label = tk.Label(frame, font=('Arial', 15), text="Flat type:")
    label.place(x=5, y=110)
    options = flat_types
    default = tk.StringVar(frame)
    default.set("Select type of HDB")
    rooms = tk.OptionMenu(frame, default, *options, )
    rooms.place(x=200, y=110)
    rooms.config(font=('Arial', 11))
    menu = frame.nametowidget(rooms.menuname)
    menu.config(font=('Arial', 13))

    return default


def get_lease(frame):
    lease_label = tk.Label(frame, text="Lease Length:", font=('Arial', 15))
    lease_label.place(x=5, y=165)
    lease = tk.Entry(frame, validate='key', font=('Arial', 12))
    lease.place(x=150, y=169)
    return lease


def get_loan(frame, loan_length, x, y):
    loan_describe = tk.Label(frame, text="Please indicate your desired housing loan period",
                             font=('Arial', 17))
    loan_describe.place(x=x, y=y + 10)
    lease_label = tk.Label(frame, text="Loan Period:", font=('Arial', 15))
    lease_label.place(x=x, y=y + 50)
    loantext = tk.StringVar(frame)
    options = list(range(loan_length + 1))
    e = tk.OptionMenu(frame, loantext, *options)
    e.place(x=x + 150, y=y + 50)
    e.config(font=('Arial', 11))
    menu = frame.nametowidget(e.menuname)
    menu.config(font=('Arial', 13))
    return loantext


def housing_frame(root, house_data):
    frame = tk.Frame(root, width=700, height=700)
    frame.place(x=0, y=0)
    title = tk.Label(frame, text="Housing Price Estimate", font=('Arial', 20))
    title.place(x=5, y=5)
    # Defining possible flat types. Adding back the base case used
    flat_types = ['1 ROOM'] + list(house_data.columns)[3:9]
    towns = ['ANG MO KIO'] + list(house_data.columns)[9:]
    flat_type = get_rooms(frame, flat_types)
    town = get_town(frame, towns)
    lease = get_lease(frame)

    loan_duration = get_loan(frame, 25, 5, 210)
    return flat_type, lease, town, loan_duration


def rental_frame(root, data):
    frame = tk.Frame(root, width=700, height=700)
    frame.place(x=0, y=0)
    title = tk.Label(frame, text="Rental Price Estimate", font=('Arial', 20))
    title.place(x=5, y=0)
    flat_types = ['2 ROOM'] + list(data.columns)[2:6]
    towns = ['ANG MO KIO'] + list(data.columns)[6:]
    flat_type = get_rooms(frame, flat_types)
    region = get_town(frame, towns)
    return region, flat_type


def house_window(root, hse):
    if housing:
        data = pd.read_csv('{}housing price data.csv'.format(FILEPATH))
        variables = list(housing_frame(root, data))

    else:
        data = pd.read_csv('{}rental price data.csv'.format(FILEPATH))
        variables = list(rental_frame(root, data))

    variables += list(hse)

    nextbutton = tk.Button(root, text="Next", command=lambda: next_button_2(root, variables, data), bg='pink',
                           font=('Arial', 15))
    nextbutton.place(x=300, y=300)
    root.mainloop()


def main():
    root = tk.Tk()
    root.title("Financial Planner")
    root.geometry('700x700')
    title = tk.Label(root, text="Financial Planner", font=('Arial', 20))
    title.place(x=5, y=0)

    quarter_hse = start_frame(root)
    car(root)
    next_button(root, quarter_hse)


if __name__ == "__main__":
    main()
    tk.mainloop()
